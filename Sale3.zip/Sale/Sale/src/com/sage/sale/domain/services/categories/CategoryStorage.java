package com.sage.sale.domain.services.categories;

import com.sage.sale.domain.services.products.Product;

public class CategoryStorage {
	public Product ResultProduct;
}
